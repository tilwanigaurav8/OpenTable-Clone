I am happy to get this opportunity of
showcasing my skills through internship 
task.
 I feel confident about my work and open
 for suggestions. The items in the folder
 are not organized properly, for which I 
 am extremely sorry. It happened because
 the path set for images was not respoding.

I will be delighted to get shortlisted as
an intern in your company.

Thank you for your faith.